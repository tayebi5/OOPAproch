﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace objectAproch
{
    internal class TwoWheeler:Vehicle,ItwoWheeler

    {
        public string ExterioerDesgine()
        {
            return "Exterioer Desgine Specific";
        }
        //answer question 1 (b)
        public string StartingMethod { get; set; }
        public int MaxPowerBHP { get; set; }
        public int MaxTorqueNM { get; set; }
        public string cooling { get; set; }
        public override void RearBreak()
        {
            Console.WriteLine("motorCycle specfic Rear Break");
        }
        public override void FrontBreak()
        {
            Console.WriteLine("motorCycle specfic Front Break");
        }
    }
}
