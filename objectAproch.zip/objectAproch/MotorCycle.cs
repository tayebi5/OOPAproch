﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace objectAproch
{
    internal class MotorCycle:TwoWheeler
    {
       public MotorCycle() { }
        //answer qestion 1(b)
        public MotorCycle(string model, int year, int gear, int seat, int Capacity,string Start,int BMPH,int NM,string Cool,VehicaleType TypeOfItem) {

            ModelNo = model;
            YearMade = year;
            NuberOfGear = gear;
            NumberOfSeat = seat;
            NumberOfCapacityCC = Capacity;
            StartingMethod = Start;
            MaxPowerBHP = BMPH;
            MaxTorqueNM = NM;
            cooling = Cool;
            Type = TypeOfItem;
        }
        public void GetModel()
        {
            Console.WriteLine($"model name is : {ModelNo}");
        }
        public override void EngineStart()
        {
            Console.WriteLine("Engine Start on sell");
        }
    }
}
