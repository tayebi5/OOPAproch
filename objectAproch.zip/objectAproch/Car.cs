﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace objectAproch
{
    sealed class Car:FourWheeler
    {
        public Car() { }
        //answer qestion 1(e)
        public Car(string model,int year,int gear,int seat,int Capacity,int Door,string Desgine ,VehicaleType typeOfItem) {
            ModelNo = model;
            YearMade = year;
            NuberOfGear = gear;
            NumberOfSeat = seat;
            NumberOfCapacityCC = Capacity;
            NumberOfDoor = Door;
            enteriorDesgine = Desgine;
            Type = typeOfItem;
        }
        //answer the question no - 1(d)
        public override void EngineStart()
        {
            Console.WriteLine("Engine Start on key");
        }
        public void CarGetModel()
        {
            Console.WriteLine($"model Name is ={ModelNo}");
        }
        public void CarGetModel(int year)
        {
            Console.WriteLine($"model Name");
        }

    }
}
