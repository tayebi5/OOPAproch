﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace objectAproch
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //answer question 1(F)
            Console.WriteLine("---------Car details-----");
            Car mycar = new Car("BMW_R5",2022,4,4,459,4,"Carbon-Cro",VehicaleType.Car);
            Console.WriteLine("Car model:"+mycar.ModelNo);
            Console.WriteLine("YearMade:" + mycar.YearMade);
            Console.WriteLine("NuberOfGear:" + mycar.NuberOfGear);
            Console.WriteLine("NumberOfSeat:" + mycar.NumberOfSeat);
            Console.WriteLine("NumberOfCapacityCC:" + mycar.NumberOfCapacityCC); 
            Console.WriteLine("NumberOfDesgine:" + mycar.NumberOfDoor);
            Console.WriteLine("enteriorDesgine:" + mycar.enteriorDesgine);
            Console.WriteLine("typeOfItem:" + mycar.Type);
            mycar.RearBreak();
            mycar.FrontBreak();
            mycar.EngineStart();
            Console.WriteLine("---------motor details-----");
            MotorCycle Mymotor = new MotorCycle("Rm-V3",2024,6,2,450,"sell",45,65,"leque",VehicaleType.MotorCycle);
            Console.WriteLine("Motor model:" + Mymotor.ModelNo);
            Console.WriteLine("YearMade:" + Mymotor.YearMade);
            Console.WriteLine("NuberOfGear:" + Mymotor.NuberOfGear);
            Console.WriteLine("MaxPowerBHP:" + Mymotor.MaxPowerBHP);
            Console.WriteLine("MaxPowerBHP:" + Mymotor.MaxPowerBHP);
            Console.WriteLine("MaxTorqueNM:" + Mymotor.MaxTorqueNM);
            Console.WriteLine("cooling:" + Mymotor.cooling);
            Console.WriteLine("NumberOfCapacityCC:" + Mymotor.NumberOfCapacityCC);
            Console.WriteLine("typeOfItem:" + Mymotor.Type);
            Mymotor.RearBreak();
            Mymotor.FrontBreak();
            Mymotor.EngineStart();

            Console.ReadLine();
        }
    }
}
