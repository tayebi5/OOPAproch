﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace objectAproch
{
    abstract class Vehicle
    {
        //Answer the question 1 (a) Property

        public string ModelNo { get; set; }
        public int YearMade { get; set; }
        public int NuberOfGear { get; set; }
        public int NumberOfSeat { get; set; }
        public int NumberOfCapacityCC { get; set; }
        public VehicaleType Type { get; set; }
        public virtual void RearBreak()
        {
            Console.WriteLine("RearBreak");
        }
        public virtual void FrontBreak()
        {
            Console.WriteLine("FrontBreak");
        }
        public virtual void EngineStart(){
            Console.WriteLine("Engine start" );
        } 
    }
}
