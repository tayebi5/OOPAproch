﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace objectAproch
{
    // answer the question no 1 (b)
    internal class FourWheeler : Vehicle, IFourWheeler
    {
        //Implement method 2 no 
        public string DetrioerDesgine()
        {
            return " DetrioerDesgine specfic";
        }
        public string enteriorDesgine { get; set; }
        public int NumberOfDoor { get; set; }
        public override void RearBreak()
        {
            Console.WriteLine("Car specfic Rear Break");
        }
        public override void FrontBreak()
        {
            Console.WriteLine("Car specfic Front Break");
        }
    }
}
